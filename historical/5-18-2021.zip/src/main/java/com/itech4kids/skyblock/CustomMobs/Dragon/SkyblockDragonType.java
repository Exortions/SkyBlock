package com.itech4kids.skyblock.CustomMobs.Dragon;

public enum SkyblockDragonType {

    SUPERIOR,
    WISE,
    UNSTABLE,
    STRONG,
    YOUNG,
    OLD,
    PROTECTOR

}
