package com.itech4kids.skyblock.Enums;

public enum MerchantType {

    MINER,
    ARMORSMITH,
    WEAPONSMITH

}