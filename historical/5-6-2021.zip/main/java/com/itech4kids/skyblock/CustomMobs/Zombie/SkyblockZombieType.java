package com.itech4kids.skyblock.CustomMobs.Zombie;

public enum SkyblockZombieType {

    GRAVEYARD,
    ZOMBIE_VILLAGER,
    LAPIS_ZOMBIE,
    OBSIDIAN_SANCTUARY,
    DIAMOND_RESERVE,
    CRYPT_GHOUL,
    GOLDEN_GHOUL,
    SEA_WALKER

}
