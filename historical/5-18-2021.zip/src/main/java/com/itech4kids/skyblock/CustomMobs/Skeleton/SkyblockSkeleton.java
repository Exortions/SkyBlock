package com.itech4kids.skyblock.CustomMobs.Skeleton;

public class SkyblockSkeleton {
}
