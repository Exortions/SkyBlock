package com.itech4kids.skyblock.CustomMobs.Wolf;

public enum SkyblockWolfType {



}
