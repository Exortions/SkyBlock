package com.itech4kids.skyblock.Enums;

public enum CollectionItemTypes {

    WHEAT,
    CARROT,
    POTATO

}