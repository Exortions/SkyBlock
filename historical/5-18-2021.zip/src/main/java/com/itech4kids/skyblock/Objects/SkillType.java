package com.itech4kids.skyblock.Objects;

public enum SkillType {

    COMBAT,
    FORAGING,
    MINING,
    ENCHANTING,
    ALCHEMY,
    SOCIAL,
    FISHING,
    FARMING,
    CATACOMBS,
    CARPENTRY,
    RUNECRAFTING,
    TAMING

}
