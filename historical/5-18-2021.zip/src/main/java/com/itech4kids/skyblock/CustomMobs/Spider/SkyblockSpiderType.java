package com.itech4kids.skyblock.CustomMobs.Spider;

public enum SkyblockSpiderType {
}
