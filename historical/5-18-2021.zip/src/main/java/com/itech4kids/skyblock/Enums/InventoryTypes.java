package com.itech4kids.skyblock.Enums;

public enum InventoryTypes {

    ANVIL("/anvil"),
    ENCHANT("/enchant"),
    ITEMBROWSER("/itembrowser"),
    SKYBLOCKMENU("/sbmenu");

    InventoryTypes(String cmd){

    }

}