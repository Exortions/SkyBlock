package com.itech4kids.skyblock.CustomMobs.Enderman;

public enum SkyblockEndermanType {

    FOUR_K,
    SIX_K,
    NINE_K,
    ZEALOT,
    SPECIAL_ZEALOT

}
